Title: Chess'N'Chat
Description: This is a Chess game me and my friend made for a project. you can play on one computer locally or online. 
Features---
- Full chess game with working rules ex: Castling, Pawn en Passant
- Change player name
- Change player icon image
- History of your moves
- View of the captured pieces
- Chat with emoticons and different font settings
You can read the User Manual in the game if you click the help.
BUGS---
 
In the chat, if your first message is only an emoticon the smiley will be misplaced on your screen. But it will show correctly on the other users screen. (ONLY HAPPENS IF FIRST MESSAGE IS AN SMILEY)
UPCOMING FEATURES---
-- Checking of Check or Check Mate

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6780&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
