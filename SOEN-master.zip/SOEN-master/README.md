SOEN 6471 Project repository
====
